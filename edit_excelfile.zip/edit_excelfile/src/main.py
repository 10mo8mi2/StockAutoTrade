'''
edit_csvfile.py
encode: utf-8
'''

from edit_csvfile import EditCsvFile
import os
import re


if __name__ == '__main__':
    ori_excel_paths = r'C:\Users\dc12224\program_file\edit_excelfile\original_csvfile'
    output_csv_path_no_filename = r'C:\Users\dc12224\program_file\edit_excelfile\making_csvfile'

    excel_files = os.listdir(ori_excel_paths)

    for excel_file in excel_files:
        print(excel_file)
        # making instance for editting csv file
        ori_excel_path = ori_excel_paths + '/' + excel_file
        edit_csvfile = EditCsvFile(ori_excel_path)
        df = edit_csvfile.making_df()
        # df = edit_csvfile.screening(df)
        # df = edit_csvfile.screening2(df)
        edit_csvfile.arrange_AD(df)
        # edit_csvfile.making_row_of_ad_year()
        edit_csvfile.count_year()

        output_csv_path = output_csv_path_no_filename + '/' + excel_file
        edit_csvfile.making_new_csvfile(output_csv_path)

