'''
edit_csvfile.py
encode: utf-8
'''

import openpyxl.workbook
import pandas as pd
import re
import datetime
import openpyxl


class EditCsvFile(object):
    def __init__(self, excel_path) -> None:
        self.excel_path = excel_path


    def making_df(self) -> None:
        self.df = pd.read_excel(self.excel_path, sheet_name='Families')
        # self.df = pd.read_excel(self.excel_path, sheet_name='PatBase 788 Fam')
        return self.df
    
    def screening(self, ori_df):
        self.df2 = ori_df[ori_df['TI'].str.contains('SWITCH')]
        # print(self.df2)
        return self.df2

    def screening2(self, edit_df):
        self.df2 = edit_df[edit_df['AB'].str.contains('pyro')]
        return self.df2

    def arrange_AD(self, df) -> None:
        self.process_df = df
        self.all_ad_list = []
        self.all_ad_year_list = []
        date_format_hyphen = '%Y-%m-%d'
        
        # making ad list of date type 
        for ad in self.process_df['AD']:
            if datetime.datetime == type(ad):
                self.all_ad_year_list.append(ad.year)
            elif '\n' in ad:
                min_ad = datetime.datetime.now()
                ad_list = re.findall(r'.+\n', ad)
                for ad_val in ad_list:
                    # removing new list(\n) and change various to date type
                    ad_val = ad_val.rstrip('\n')
                    ad_val_date = datetime.datetime.strptime(ad_val, date_format_hyphen)
                    # looking for minimum ad
                    if min_ad > ad_val_date:
                        min_ad = ad_val_date
                self.all_ad_list.append(min_ad)
            
        
        for ad_year in self.all_ad_list:
            self.all_ad_year_list.append(ad_year.year)


    def making_row_of_ad_year(self) -> None:
        self.process_df['AD_year'] = self.all_ad_year_list

    def count_year(self) -> None:
        # defined each various
        min_ad_year = min(self.all_ad_year_list)
        current_time = datetime.date.today()
        current_year = current_time.year
        self.dict_count_val = {}

        # counting patent value in each ad
        for year in range(min_ad_year, current_year):
            self.dict_count_val[year] = self.all_ad_year_list.count(year)


    def making_new_csvfile(self, output_excel_path) -> None:
        self.output_excel_path = output_excel_path
        wb = openpyxl.Workbook()
        ws = wb.active

        for i, (key, val) in enumerate(self.dict_count_val.items()):
            ws.cell(row = 1 + i, column = 1, value = key)
            ws.cell(row = 1 + i, column = 2, value = val)

        wb.save(self.output_excel_path)

        with pd.ExcelWriter(output_excel_path, mode='a') as writer:
            self.process_df.to_excel(writer, sheet_name='patent_info')

        # with open(self.output_excel_path, 'w') as f:
        #     writer = csv.writer(f)
        #     for key, val in self.dict_count_val.items():
        #         writer.writerow([key, val])
        # self.df.to_csv(self.output_excel_path, columns=['PN', 'AD_year'])
