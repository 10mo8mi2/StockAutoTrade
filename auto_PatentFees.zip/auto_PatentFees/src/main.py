'''
main.py
encode: utf-8
'''

import pandas as pd
import os
import datetime
import glob
from processing_csvfile import processing_csvflile
import openpyxl

if __name__ == '__main__':
    # getting datetime
    date = datetime.datetime.now()
    # defining excel file and make change file name by month
    if 5 <=date.month <= 12:
        excel_path = '~/auto_patentFees/各月実績' + str(date.year)[2:4] + '年度.xlsx'
    else:
        excel_path = '~/auto_patentFees/各月実績' + str(date.year - 1)[2:4] + '年度.xlsx'
    # defining path and file name
    excel_path = os.path.expanduser(excel_path)
    csv_path = os.path.expanduser('~/auto_PatentFees/特許手数料csv保管フォルダ')
    csv_file_list = glob.glob(csv_path + '/セイフティ特許手数料*')
    
    for path in csv_file_list:
        # getting csv data
        month_num = int(path[-6:-4])
        csv_df = pd.read_csv(path, encoding = 'cp932')
        # making new sheet to excel file
        # wb = openpyxl.load_workbook(excel_path)
        sheet_name = path[-9:-7] + path[-6:-4]
        print(sheet_name)
        # wb.create_sheet(title = sheet_name)
        # wb.save(excel_path)
        processing_csvflile(csv_df, excel_path, month_num, sheet_name)
        print('Done processing in {}'.format(path))