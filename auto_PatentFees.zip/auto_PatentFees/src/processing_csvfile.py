'''
processing_csvfile
encode: utf-8
'''

import pandas as pd
import openpyxl

def processing_csvflile(csv_df, excel_path, month_num, newsheet_name):
    # separating dataframe by department code
    df_mob = csv_df[csv_df['部門コード'].str.contains('セイフティ_モビリティ')]
    df_GG = csv_df[csv_df['部門コード'].str.contains('セイフティ_ガス発生剤')]
    df_indus = csv_df[csv_df['部門コード'].str.contains('セイフティ_インダストリ')]

    # writing each information to excel file
    wb = openpyxl.load_workbook(excel_path)
    check = False
    for ws in wb.worksheets:
        if ws.title == newsheet_name:
            check = True
    # checking whether file exists
    if check == True:            
        with pd.ExcelWriter(excel_path, mode = 'a', if_sheet_exists = 'overlay') as writer:
            df_mob.to_excel(
                writer,
                sheet_name = newsheet_name,
                startrow = 1,
                startcol = 0,
                index = False
            )
            df_GG.to_excel(
                writer,
                sheet_name = newsheet_name,
                startrow = df_mob.shape[0] + 8,
                startcol = 0,
                index = False
            )
            df_indus.to_excel(
                writer,
                sheet_name = newsheet_name,
                startrow = df_mob.shape[0] + 8 + df_GG.shape[0] + 8,
                startcol = 0,
                index = False
            )
    else:
        with pd.ExcelWriter(excel_path, mode='a', if_sheet_exists = 'new') as writer:
            df_mob.to_excel(
                writer,
                sheet_name = newsheet_name,
                startrow = 1,
                startcol = 0,
                index = False
            )
        with pd.ExcelWriter(excel_path, mode='a', if_sheet_exists = 'overlay') as writer:
            df_GG.to_excel(
                writer,
                sheet_name = newsheet_name,
                startrow = df_mob.shape[0] + 8,
                startcol = 0,
                index = False
            )
            df_indus.to_excel(
                writer,
                sheet_name = newsheet_name,
                startrow = df_mob.shape[0] + 8 + df_GG.shape[0] + 8,
                startcol = 0,
                index = False
            )
    print(newsheet_name)
    ws = wb[newsheet_name]
    ws['A1'] = 'MSD(A11)'
    cell= 'A' + str(df_mob.shape[0] + 8)
    ws[cell] = '剤(A13)'
    cell = 'A' + str(df_mob.shape[0] + 8 + df_GG.shape[0] + 8)
    ws[cell] = 'インダストリ(A14)'
    wb.save(excel_path)
    print('mobility')
    writing_fee_to_excel(df_mob, excel_path, 'MSD(A11)', month_num)
    print('GG')
    writing_fee_to_excel(df_GG, excel_path, '剤（A13)', month_num)
    print('industry')
    writing_fee_to_excel(df_indus, excel_path, 'インダストリ（A14)', month_num)

    
def writing_fee_to_excel(df, excel_path, code_name, month_num):
    # defining each fee variable
    apply_fee_internal = 0
    apply_fee_abroad = 0
    prose_fee_internal = 0
    prose_fee_abroad = 0
    main_fee_internal = 0
    main_fee_abroad = 0
    consul_fee_internal = 0
    consul_fee_abroad = 0
    mark_fee_internal = 0
    mark_fee_abroad = 0

    # calculating each fee
    for row, data in df.iterrows():
        if '特許' in data['対象案件四法']:
            if '出願' in data['費用種別'] and '審査請求' not in data['費用種別'] and '年金' not in data['費用種別']:
                if '日本' in data['対象案件国']:
                    # print(f"{data['受付番号']} -> {data['支払額合計（支払通貨）']}")
                    apply_fee_internal += data['支払額合計（支払通貨）'] / 1000
                else:
                    # print(f"{data['受付番号']} -> {data['支払額合計（支払通貨）']}")
                    apply_fee_abroad += data['支払額合計（支払通貨）'] / 1000

            if '審査請求' in data['費用種別'] or '審判' in data['費用種別'] or '中間' in data['費用種別'] and '年金' not in data['費用種別']:
                if '日本' in data['対象案件国']:
                    prose_fee_internal += data['支払額合計（支払通貨）'] / 1000
                else:
                    prose_fee_abroad += data['支払額合計（支払通貨）'] / 1000

            if '年金' in data['費用種別'] and '出願' not in data['費用種別']:
                if '日本' in data['対象案件国']:
                    main_fee_internal += data['支払額合計（支払通貨）'] / 1000
                else:
                    main_fee_abroad += data['支払額合計（支払通貨）'] / 1000
            
            # if '商標' in data['費用種別']:
            #     if '日本' in data['対象案件国']:
            #         mark_fee_internal += data['支払額合計（支払通貨）'] / 1000
            #     else:
            #         mark_fee_abroad += data['支払額合計（支払通貨）'] / 1000
                
            if '鑑定' in data['費用種別']:
                if '日本' in data['対象案件国']:
                    consul_fee_internal += data['支払額合計（支払通貨）'] / 1000
                else:
                    consul_fee_abroad += data['支払額合計（支払通貨）'] / 1000
        elif '商標' in data['対象案件四法']:
            if '日本' in data['対象案件国']:
                mark_fee_internal += data['支払額合計（支払通貨）'] / 1000
            else:
                mark_fee_abroad += data['支払額合計（支払通貨）'] / 1000

    
    apply_fee_total = apply_fee_internal + apply_fee_abroad
    prose_fee_total = prose_fee_internal + prose_fee_abroad
    main_fee_total = main_fee_internal + main_fee_abroad
    mark_fee_total = mark_fee_internal + mark_fee_abroad
    internal_total = apply_fee_internal + prose_fee_internal + main_fee_internal + mark_fee_internal
    abroad_total = apply_fee_abroad + prose_fee_abroad + main_fee_abroad + mark_fee_abroad
    all_total = internal_total + abroad_total

    # making summary dataframe for writing to excel
    summary_df = pd.DataFrame(
        data={
                '国内出願':             [apply_fee_internal],
                '国内権利化':           [prose_fee_internal],
                '国内権利維持':         [main_fee_internal],
                '国内相談・鑑定':       [consul_fee_internal],
                '国内小計':             [internal_total],
                '海外出願':             [apply_fee_abroad],
                '海外権利化':           [prose_fee_abroad],
                '海外権利維持':         [main_fee_abroad],
                '海外相談・鑑定':       [consul_fee_abroad],
                '海外小計':             [abroad_total],
                '商標':                 [mark_fee_total]
        }
    )

    # writing dataframe to excel, changing writing point by month
    if 4 <= month_num <= 9: 
        with pd.ExcelWriter(excel_path, mode='a', if_sheet_exists='overlay') as writer:
            summary_df.to_excel(
                writer,
                sheet_name = code_name,
                startrow = month_num + 3,
                startcol = 1,
                index = False,
                header = False
            )
        # writing passing month
        wb = openpyxl.load_workbook(excel_path)
        ws = wb['総計']
        ws["C25"] = month_num - 3
        wb.save(excel_path)
    elif 1 <= month_num <= 3:
        with pd.ExcelWriter(excel_path, mode='a', if_sheet_exists='overlay') as writer:
            summary_df.to_excel(
                writer,
                sheet_name = code_name,
                startrow = month_num + 26,
                startcol = 1,
                index = False,
                header = False
            )
        # writing passing month
        wb = openpyxl.load_workbook(excel_path)
        ws = wb['総計']
        ws["C63"] = month_num + 3
        wb.save(excel_path)
    else:
        with pd.ExcelWriter(excel_path, mode='a', if_sheet_exists='overlay') as writer:
            summary_df.to_excel(
                writer,
                sheet_name = code_name,
                startrow = month_num + 14,
                startcol = 1,
                index = False,
                header = False
            )
        # writing passing month
        wb = openpyxl.load_workbook(excel_path)
        ws = wb['総計']
        ws["C63"] = month_num - 9
        wb.save(excel_path)